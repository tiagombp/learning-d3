// generates a small dataset

let dataset = [
  ...Array(98).fill("cat1"),
  ...Array(41).fill("cat2"), 
  ...Array(24).fill("cat3"),
  ...Array(83).fill("cat4"),
  ...Array(60).fill("cat5")
];

// basic parameters

let radius = 3;
let dots_per_row = 5;
let space_between_dots = radius;
let space_between_columns = 4 * radius;

// data preparation

let columns_width = (2*radius + space_between_dots) * dots_per_row;

let categories = d3.map(dataset, d => d).keys();

let number_of_columns = categories.length;
let total_needed_width = columns_width * number_of_columns + space_between_columns * (number_of_columns -1);

let data = []

categories.forEach((cat,cat_index) => {
  let mini_dataset = dataset.filter(d => d == cat);
  mini_dataset.forEach((d, i) => data.push({ 
    "relative_index":  i,
    "x" :cat_index * (columns_width + space_between_columns) + (i % dots_per_row) * (2*radius + space_between_dots),
    "y" : Math.floor(i / dots_per_row),
    "cat" : cat
  }))
});

let max_y = d3.max(data, d => d.y);
let total_needed_height = (2*radius + space_between_dots) * max_y;

console.log(total_needed_width, total_needed_height);

// margins

let w_container = +d3.select("div.svg-container").style("width").slice(0,-2);
let h_container = +d3.select("div.svg-container").style("height").slice(0,-2);

let margin_bottom = 50;

let margins = {
  "h" : (w_container - total_needed_width)/2,
  "bottom" : margin_bottom,
  "top": h_container - total_needed_height - margin_bottom
}

// scales
const x = d3.scaleLinear()
  .domain(d3.extent(data, d => d.x))
  .range([margins.h, margins.h + total_needed_width]);

const y = d3.scaleLinear()
  .domain(d3.extent(data, d => d.y))
  .range([h_container - margins.bottom,
         margins.top]);

const color = d3.scaleOrdinal()
.domain(categories)
.range(d3.schemeTableau10.concat(d3.schemeSet3));

// draw

let dots = d3.select("svg")
  .selectAll("circle")
  .data(data)
  .enter()
  .append("circle")
  .attr("cx", d => x(d.x))
  .attr("cy", d => y(d.y))
  .attr("r", radius)
  .attr("fill", d => color(d.cat));

// labels

let labels = d3.scaleBand()
  .domain(categories)
  .range([
    x.range()[0]-columns_width/2,
    x.range()[1]+columns_width/2])
  .paddingInner(0)
  .paddingOuter(.2);

let labels_axis = d3.axisBottom().scale(labels);

d3.select("svg")
  .append("g")
  .classed("axis", true)
  .call(labels_axis)
  .attr("transform", "translate(0," + (h_container - margins.bottom + space_between_columns) +")")
  .select(".domain").remove();




